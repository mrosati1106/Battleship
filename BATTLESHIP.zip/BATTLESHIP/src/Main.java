import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import java.util.Random;
import java.util.ArrayList;


public class Main {

    static String turn, selectedLetter, comTurn;
    static int clickCounter = 0;
    static gridMaker grid, enemyGrid;
    static JFrame gridFrame, enemyGridFrame;
    static boat comBoat1 = new boat(3), comBoat2 = new boat(4), comBoat3 = new boat(5), comBoat4 = new boat(3), comBoat5 = new boat(4);
    static boat playerBoat1 = new boat(3), playerBoat2 = new boat(4), playerBoat3 = new boat(5), playerBoat4 = new boat(3), playerBoat5 = new boat(4);

    static ArrayList<String> comBoatPositions = new ArrayList<String>(), playerBoatPositions = new ArrayList<String>(), usedPlayerTurns = new ArrayList<String>(), usedComTurns = new ArrayList<String>();
    static ArrayList<boat> comBoatList = new ArrayList<boat>(), playerBoatList = new ArrayList<boat>();


    public static void main(String[] args) {
        Color blueBackgroundColor = new Color(180, 212, 234);
        Color redBackgroundColor = new Color(255, 204, 203);

        JFrame mainMenu = new JFrame("BATTLESHIP");
        mainMenu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainMenu.setVisible(true);
        mainMenu.setSize(300, 190);
        mainMenu.setBackground(blueBackgroundColor);
        mainMenu.setLocationRelativeTo(null);
        JPanel menuPanel = new JPanel();
        menuPanel.setVisible(true);
        menuPanel.setBounds(0, 0, 500, 250);
        menuPanel.setBackground(blueBackgroundColor);
        mainMenu.add(menuPanel);
        imageUploader("title.png", menuPanel, 150, 10, 200, 80);
        JButton playButton = new JButton();
        playButton.setBounds(165, 100, 160, 50);
        ImageIcon computerImage = new ImageIcon("computer.png");
        playButton.setIcon(computerImage);
        playButton.setVisible(true);
        menuPanel.add(playButton);
        mainMenu.revalidate();
        mainMenu.setResizable(false);

        gridFrame = new JFrame("YOUR BOARD");
        gridFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        grid = new gridMaker();
        gridFrame.add(grid);
        gridFrame.setSize(600, 625);
        grid.setBackground(blueBackgroundColor);
        gridFrame.setResizable(false);

        JFrame inputFrame = new JFrame("INPUT:");
        inputFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        inputFrame.setSize(400, 130);
        inputFrame.setResizable(false);
        inputFrame.setLayout(null);
        inputFrame.setLocation(650, 700);

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(null);
        inputPanel.setBounds(0, 0, 400, 120);
        inputFrame.add(inputPanel);
        inputPanel.setBackground(blueBackgroundColor);

        JLabel attackLabel = new JLabel("Enter where you'd like to attack:");
        inputPanel.add(attackLabel);
        attackLabel.setBounds(20, 2, 500, 50);


        String[] letters = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J"};
        JComboBox<String> letterDropdown = new JComboBox<>(letters);
        letterDropdown.setBounds(16, 40, 90, 25);
        inputPanel.add(letterDropdown);
        letterDropdown.setVisible(true);
        inputFrame.revalidate();
        inputFrame.repaint();
        // these two lines fix an issue where the input field is invisible unless the frame is resized.
        String[] numbers = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        JComboBox<String> numberDropdown = new JComboBox<>(numbers);
        numberDropdown.setBounds(116, 40, 90, 25);
        inputPanel.add(numberDropdown);
        numberDropdown.setVisible(true);
        inputFrame.revalidate();
        inputFrame.repaint();

        JButton inputConfirmation = new JButton("Confirm");
        inputConfirmation.setBounds(20, 70, 72, 20);
        inputConfirmation.setVisible(true);
        inputPanel.add(inputConfirmation);
        inputFrame.revalidate();
        inputFrame.repaint();

        JFrame gameStatusFrame = new JFrame("GAME OVER");
        gameStatusFrame.setSize(600, 300);
        gameStatusFrame.setLocationRelativeTo(null);
        gameStatusFrame.setLayout(null);
        JPanel gameStatusPanel = new JPanel();
        gameStatusPanel.setLayout(null);
        gameStatusFrame.add(gameStatusPanel);
        gameStatusPanel.setBounds(0, 0, 600, 300);
        gameStatusFrame.setBackground(blueBackgroundColor);
        gameStatusPanel.setBackground(blueBackgroundColor);
        gameStatusFrame.setVisible(false);
        gameStatusFrame.setResizable(false);
        JLabel winLabel = new JLabel();
        ImageIcon winIcon = new ImageIcon("win.png");
        winLabel.setIcon(winIcon);
        winLabel.setVisible(false);
        winLabel.setBounds(50, 50, 500, 200);
        gameStatusFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gameStatusPanel.add(winLabel);
        JLabel loseLabel = new JLabel();
        ImageIcon loseIcon = new ImageIcon("lose.png");
        loseLabel.setIcon(loseIcon);
        loseLabel.setVisible(false);
        loseLabel.setBounds(50, 50, 500, 200);
        gameStatusPanel.add(loseLabel);

        JLabel duplicateMessage = new JLabel("That cell has already been hit!");
        inputPanel.add(duplicateMessage);
        duplicateMessage.setBounds(100, 70, 300, 20);
        duplicateMessage.setVisible(false);


        JFrame boatFrame = new JFrame("INPUT:");
        boatFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        boatFrame.setSize(400, 130);
        boatFrame.setResizable(false);
        boatFrame.setLayout(null);
        JPanel boatPanel = new JPanel();
        boatPanel.setLayout(null);
        boatPanel.setBounds(0, 0, 400, 120);
        boatFrame.add(boatPanel);
        boatPanel.setBackground(blueBackgroundColor);

        JLabel boatLabel = new JLabel("Enter where you'd like to place your boat: (3-wide)");
        boatPanel.add(boatLabel);
        boatLabel.setBounds(20, 2, 500, 50);


        JComboBox<String> letterDropdown2 = new JComboBox<>(letters);
        letterDropdown2.setBounds(16, 40, 90, 25);
        boatPanel.add(letterDropdown2);
        letterDropdown2.setVisible(true);
        boatFrame.revalidate();
        boatFrame.repaint();
        // these two lines fix an issue where the input field is invisible unless the frame is resized.
        JComboBox<String> numberDropdown2 = new JComboBox<>(numbers);
        numberDropdown2.setBounds(116, 40, 90, 25);
        boatPanel.add(numberDropdown2);
        numberDropdown2.setVisible(true);
        boatFrame.revalidate();
        boatFrame.repaint();
        boatFrame.setLocation(0, 700);

        JButton boatConfirmation = new JButton("Confirm");
        boatConfirmation.setBounds(20, 70, 72, 20);
        boatConfirmation.setVisible(true);
        boatPanel.add(boatConfirmation);
        boatFrame.revalidate();
        boatFrame.repaint();


        JLabel occupiedMessage = new JLabel("That ship can't fit there!");
        boatPanel.add(occupiedMessage);
        occupiedMessage.setBounds(100, 70, 300, 20);
        occupiedMessage.setVisible(false);
        boatConfirmation.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent click) {

                selectedLetter = (String) letterDropdown2.getSelectedItem();
                String number = (String) numberDropdown2.getSelectedItem();
                turn = selectedLetter + Integer.parseInt(number);
                int xPosition = letterToNumber(selectedLetter.charAt(0));

                boolean duplicate = false;

                for (int i = 0; i < playerBoatPositions.size(); i++) {
                    if (turn.equals(playerBoatPositions.get(i)) || (clickCounter == 0 && xPosition > 8) || (clickCounter == 1 && xPosition > 7) || (clickCounter == 2 && xPosition > 6) || (clickCounter == 3 && xPosition > 8) || (clickCounter == 4 && xPosition > 7) || (clickCounter == 0 && (numberToLetter(xPosition + 1) + number).equals(playerBoatPositions.get(i))) || (clickCounter == 0 && (numberToLetter(xPosition + 2) + number).equals(playerBoatPositions.get(i))) || (clickCounter == 1 && (numberToLetter(xPosition + 1) + number).equals(playerBoatPositions.get(i))) || (clickCounter == 1 && (numberToLetter(xPosition + 2) + number).equals(playerBoatPositions.get(i))) || (clickCounter == 1 && (numberToLetter(xPosition + 3) + number).equals(playerBoatPositions.get(i))) || (clickCounter == 2 && (numberToLetter(xPosition + 1) + number).equals(playerBoatPositions.get(i))) || (clickCounter == 2 && (numberToLetter(xPosition + 2) + number).equals(playerBoatPositions.get(i))) || (clickCounter == 2 && (numberToLetter(xPosition + 3) + number).equals(playerBoatPositions.get(i))) || (clickCounter == 2 && (numberToLetter(xPosition + 4) + number).equals(playerBoatPositions.get(i))) || (clickCounter == 3 && (numberToLetter(xPosition + 1) + number).equals(playerBoatPositions.get(i))) || (clickCounter == 3 && (numberToLetter(xPosition + 2) + number).equals(playerBoatPositions.get(i))) || (clickCounter == 4 && (numberToLetter(xPosition + 1) + number).equals(playerBoatPositions.get(i))) || (clickCounter == 4 && (numberToLetter(xPosition + 2) + number).equals(playerBoatPositions.get(i))) || (clickCounter == 4 && (numberToLetter(xPosition + 3) + number).equals(playerBoatPositions.get(i)))) {
                        duplicate = true;
                        occupiedMessage.setVisible(true);
                        Timer timer = new Timer(2000, event -> {
                            occupiedMessage.setVisible(false);
                            ((Timer) event.getSource()).stop();
                        });
                        timer.start();
                        break;
                    }

                }
                if (!duplicate) {
                    clickCounter++;
                    if (clickCounter == 1) {
                        playerBoat(turn, playerBoat1);
                        printBoat(playerBoat1, grid);
                        boatLabel.setText("Enter where you'd like to place your boat: (4-wide)");
                        for (int x = 0; x < playerBoat1.xPositions.length; x++) {
                            System.out.println(playerBoat1.xPositions[x]);
                        }
                    } else if (clickCounter == 2) {
                        playerBoat(turn, playerBoat2);
                        printBoat(playerBoat2, grid);
                        boatLabel.setText("Enter where you'd like to place your boat: (5-wide)");
                        for (int x = 0; x < playerBoat2.xPositions.length; x++) {
                            System.out.println(playerBoat2.xPositions[x]);
                        }
                    } else if (clickCounter == 3) {
                        playerBoat(turn, playerBoat3);
                        printBoat(playerBoat3, grid);
                        boatLabel.setText("Enter where you'd like to place your boat: (3-wide)");
                        for (int x = 0; x < playerBoat3.xPositions.length; x++) {
                            System.out.println(playerBoat3.xPositions[x]);
                        }
                    } else if (clickCounter == 4) {
                        playerBoat(turn, playerBoat4);
                        printBoat(playerBoat4, grid);
                        boatLabel.setText("Enter where you'd like to place your boat: (4-wide)");
                        for (int x = 0; x < playerBoat4.xPositions.length; x++) {
                            System.out.println(playerBoat4.xPositions[x]);
                        }
                    } else if (clickCounter == 5) {
                        playerBoat(turn, playerBoat5);
                        printBoat(playerBoat5, grid);
                        for (int x = 0; x < playerBoat5.xPositions.length; x++) {
                            System.out.println(playerBoat5.xPositions[x]);
                        }
                        boatFrame.setVisible(false);
                        inputFrame.setVisible(true);
                        enemyGridFrame.setVisible(true);
                    }


                }


            }
        });
        inputConfirmation.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent click) {
                selectedLetter = (String) letterDropdown.getSelectedItem();
                String number = (String) numberDropdown.getSelectedItem();
                turn = selectedLetter + Integer.parseInt(number);

                boolean duplicate = false;
                for (int x = 0; x < usedPlayerTurns.size(); x++) {
                    if (turn.equals(usedPlayerTurns.get(x))) {
                        duplicate = true;
                        duplicateMessage.setVisible(true);
                        Timer timer = new Timer(2000, event -> {
                            duplicateMessage.setVisible(false);
                            ((Timer) event.getSource()).stop();
                        });
                        timer.start();
                        break;
                    }
                }
                if (!duplicate) {
                    usedPlayerTurns.add(turn);
                    hit(turn, enemyGrid, enemyGridFrame, comBoatPositions);
                    for (int x = 0; x < comBoat1.xPositions.length; x++) {
                        System.out.println((numberToLetter(comBoat1.yPosition) + comBoat1.xPositions[x]));
                    }

                    for (int x = 0; x < comBoat1.xPositions.length; x++) {
                        if ((numberToLetter(comBoat1.xPositions[x]) + comBoat1.yPosition).equals(turn)) {
                            comBoat1.cells--;
                        }
                    }
                    for (int x = 0; x < comBoat2.xPositions.length; x++) {
                        if ((numberToLetter(comBoat2.xPositions[x]) + comBoat2.yPosition).equals(turn)) {
                            comBoat2.cells--;
                        }
                    }
                    for (int x = 0; x < comBoat3.xPositions.length; x++) {
                        if ((numberToLetter(comBoat3.xPositions[x]) + comBoat3.yPosition).equals(turn)) {
                            comBoat3.cells--;
                        }
                    }
                    for (int x = 0; x < comBoat4.xPositions.length; x++) {
                        if ((numberToLetter(comBoat4.xPositions[x]) + comBoat4.yPosition).equals(turn)) {
                            comBoat4.cells--;
                        }
                    }
                    for (int x = 0; x < comBoat5.xPositions.length; x++) {
                        if ((numberToLetter(comBoat5.xPositions[x]) + comBoat5.yPosition).equals(turn)) {
                            comBoat5.cells--;
                        }
                    }
                    if (comBoat1.cells == 0 && comBoat1.alive) {
                        printBoat(comBoat1, enemyGrid);
                        comBoat1.alive = false;
                    }
                    if (comBoat2.cells == 0 && comBoat2.alive) {
                        printBoat(comBoat2, enemyGrid);
                        comBoat2.alive = false;
                    }
                    if (comBoat3.cells == 0 && comBoat3.alive) {
                        printBoat(comBoat3, enemyGrid);
                        comBoat3.alive = false;
                    }
                    if (comBoat4.cells == 0 && comBoat4.alive) {
                        printBoat(comBoat4, enemyGrid);
                        comBoat4.alive = false;
                    }
                    if (comBoat5.cells == 0 && comBoat5.alive) {
                        printBoat(comBoat5, enemyGrid);
                        comBoat5.alive = false;
                    }
                    if (!comBoat1.alive && !comBoat2.alive && !comBoat3.alive && !comBoat4.alive && !comBoat5.alive) {
                        inputFrame.setVisible(false);
                        gameStatusFrame.setVisible(true);
                        winLabel.setVisible(true);
                    } else {
                        Random random = new Random();
                        boolean comDuplicate = false;
                        do {
                            int comXPositionNum = random.nextInt(10) + 1;
                            int comYPosition = random.nextInt(10) + 1;
                            String comXPosition = numberToLetter(comXPositionNum);
                            comTurn = comXPosition + comYPosition;
                            for (int x = 0; x < usedComTurns.size(); x++) {
                                if (comTurn.equals(usedComTurns.get(x))) {
                                    comDuplicate = true;
                                    break;
                                } else {
                                    comDuplicate = false;
                                }
                            }
                        } while (comDuplicate);
                        usedComTurns.add(comTurn);
                        hit(comTurn, grid, gridFrame, playerBoatPositions);
                        for (int x = 0; x < playerBoat1.xPositions.length; x++) {
                            if ((numberToLetter(playerBoat1.xPositions[x]) + playerBoat1.yPosition).equals(comTurn)) {
                                playerBoat1.cells--;
                            }
                        }
                        for (int x = 0; x < playerBoat2.xPositions.length; x++) {
                            if ((numberToLetter(playerBoat2.xPositions[x]) + playerBoat2.yPosition).equals(comTurn)) {
                                playerBoat2.cells--;
                            }
                        }
                        for (int x = 0; x < playerBoat3.xPositions.length; x++) {
                            if ((numberToLetter(playerBoat3.xPositions[x]) + playerBoat3.yPosition).equals(comTurn)) {
                                playerBoat3.cells--;
                            }
                        }
                        for (int x = 0; x < playerBoat4.xPositions.length; x++) {
                            if ((numberToLetter(playerBoat4.xPositions[x]) + playerBoat4.yPosition).equals(comTurn)) {
                                playerBoat4.cells--;
                            }
                        }
                        for (int x = 0; x < playerBoat5.xPositions.length; x++) {
                            if ((numberToLetter(playerBoat5.xPositions[x]) + playerBoat5.yPosition).equals(comTurn)) {
                                playerBoat5.cells--;
                            }
                        }
                        if (playerBoat1.cells == 0) {
                            printBoat(playerBoat1, grid);
                            playerBoat1.alive = false;
                        }
                        if (playerBoat2.cells == 0) {
                            printBoat(playerBoat2, grid);
                            playerBoat2.alive = false;
                        }
                        if (playerBoat3.cells == 0) {
                            printBoat(playerBoat3, grid);
                            playerBoat3.alive = false;
                        }
                        if (playerBoat4.cells == 0) {
                            printBoat(playerBoat4, grid);
                            playerBoat4.alive = false;
                        }
                        if (playerBoat5.cells == 0) {
                            printBoat(playerBoat5, grid);
                            playerBoat5.alive = false;
                        }
                        if (!playerBoat1.alive && !playerBoat2.alive && !playerBoat3.alive && !playerBoat4.alive && !playerBoat5.alive) {
                            inputFrame.setVisible(false);
                            gameStatusFrame.setVisible(true);
                            loseLabel.setVisible(true);
                        }
                    }
                }
            }

        });


        enemyGridFrame = new JFrame("ENEMY BOARD");
        enemyGridFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        enemyGrid = new gridMaker();
        enemyGridFrame.add(enemyGrid);
        enemyGridFrame.setSize(600, 625);
        enemyGrid.setBackground(redBackgroundColor);
        enemyGridFrame.setResizable(false);
        enemyGridFrame.setLocation(650, 0);

        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent click) {
                mainMenu.setVisible(false);
                gridFrame.setVisible(true);
                boatFrame.setVisible(true);

            }
        });
        comBoatPicker();


    }


    public static int letterToNumber(char letter) {
        // turns a letter from A to J into a number from 1 to 10

        int col = -1;
        if (letter == 'A') {
            col = 1;
        } else if (letter == 'B') {
            col = 2;
        } else if (letter == 'C') {
            col = 3;
        } else if (letter == 'D') {
            col = 4;
        } else if (letter == 'E') {
            col = 5;
        } else if (letter == 'F') {
            col = 6;
        } else if (letter == 'G') {
            col = 7;
        } else if (letter == 'H') {
            col = 8;
        } else if (letter == 'I') {
            col = 9;
        } else if (letter == 'J') {
            col = 10;
        }
        return col;
    }

    public static String numberToLetter(int number) {
        // turns a number from 1 to 10 into a letter from A to J

        String letter = "";
        if (number == 1) {
            letter = "A";
        } else if (number == 2) {
            letter = "B";
        } else if (number == 3) {
            letter = "C";
        } else if (number == 4) {
            letter = "D";
        } else if (number == 5) {
            letter = "E";
        } else if (number == 6) {
            letter = "F";
        } else if (number == 7) {
            letter = "G";
        } else if (number == 8) {
            letter = "H";
        } else if (number == 9) {
            letter = "I";
        } else if (number == 10) {
            letter = "J";
        } else if (number > 10) {
            letter = "Z";
        }
        return letter;
    }

    public static void imageUploaderGrid(String filename, gridMaker grid, int x, int y, int w, int h) {
        // Uploads images to any grid (different from imageUploader as grids are their own class called gridMaker)
        ImageIcon image = new ImageIcon(filename);
        JLabel imageLabel = new JLabel();
        imageLabel.setIcon(image);
        grid.add(imageLabel);
        grid.setLayout(null);
        grid.setVisible(true);
        imageLabel.setBounds(x, y, w, h);
        grid.repaint();
    }

    public static void imageUploader(String filename, JPanel panel, int x, int y, int w, int h) {
        // Uploads images to any panel
        ImageIcon image = new ImageIcon(filename);
        JLabel imageLabel = new JLabel();
        imageLabel.setIcon(image);
        panel.add(imageLabel);
        panel.setVisible(true);
        imageLabel.setBounds(x, y, w, h);
        panel.repaint();
    }

    public static void hit(String turn, gridMaker grid, JFrame frame, ArrayList<String> positionList) {
        // takes a grid, frame, list of positions, and a point on the grid and makes a red or white square appear
        // depending on whether the turn was a hit or miss
        System.out.println(turn);
        char letter = turn.charAt(0);
        int x, y;
        int col = letterToNumber(letter);
        int row = Integer.parseInt(turn.substring(1));
        int diameter = 10;
        x = 25 + 50 * col;
        y = 25 + 50 * row;
        JPanel panel = new JPanel();
        panel.setPreferredSize(new Dimension(diameter, diameter));
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);
        for (int i = 0; i < positionList.size(); i++) {
            if (positionList.get(i).equalsIgnoreCase(turn)) {
                panel.setBackground(Color.RED);
            }
        }
        grid.setLayout(null);
        frame.setLayout(null);
        grid.add(panel);
        panel.setBounds(x - 5, y - 3, diameter, diameter);
        frame.revalidate();
        frame.repaint();
    }

    public static void comBoatPicker() {
        // Picks the computers boats
        Random random = new Random();
        String point;
        int yPositionBoat1 = random.nextInt(10) + 1;
        int yPositionBoat2;
        do {
            yPositionBoat2 = random.nextInt(10) + 1;
        } while (yPositionBoat2 == yPositionBoat1);
        int yPositionBoat3;
        do {
            yPositionBoat3 = random.nextInt(10) + 1;
        } while (yPositionBoat3 == yPositionBoat2 || yPositionBoat3 == yPositionBoat1);
        int yPositionBoat4;
        do {
            yPositionBoat4 = random.nextInt(10) + 1;
        } while (yPositionBoat4 == yPositionBoat3 || yPositionBoat4 == yPositionBoat2 || yPositionBoat4 == yPositionBoat1);
        int yPositionBoat5;
        do {
            yPositionBoat5 = random.nextInt(10) + 1;
        } while (yPositionBoat5 == yPositionBoat4 || yPositionBoat5 == yPositionBoat3 || yPositionBoat5 == yPositionBoat2 || yPositionBoat5 == yPositionBoat1);
        int xPositionBoat1 = random.nextInt(8) + 1;
        int xPositionBoat4 = random.nextInt(8) + 1;
        int xPositionBoat2 = random.nextInt(7) + 1;
        int xPositionBoat5 = random.nextInt(7) + 1;
        int xPositionBoat3 = random.nextInt(6) + 1;

        comBoat1.yPosition = yPositionBoat1;
        comBoat1.xPositions[0] = xPositionBoat1;
        point = numberToLetter(comBoat1.xPositions[0]) + (comBoat1.yPosition);
        comBoatPositions.add(point);
        comBoat1.xPositions[1] = (xPositionBoat1 + 1);
        point = numberToLetter(comBoat1.xPositions[1]) + (comBoat1.yPosition);
        comBoatPositions.add(point);
        comBoat1.xPositions[2] = (xPositionBoat1 + 2);
        point = numberToLetter(comBoat1.xPositions[2]) + (comBoat1.yPosition);
        comBoatPositions.add(point);
        comBoatList.add(comBoat1);

        comBoat4.yPosition = yPositionBoat4;
        comBoat4.xPositions[0] = xPositionBoat4;
        point = numberToLetter(comBoat4.xPositions[0]) + (comBoat4.yPosition);
        comBoatPositions.add(point);
        comBoat4.xPositions[1] = (xPositionBoat4 + 1);
        point = numberToLetter(comBoat4.xPositions[1]) + (comBoat4.yPosition);
        comBoatPositions.add(point);
        comBoat4.xPositions[2] = (xPositionBoat4 + 2);
        point = numberToLetter(comBoat4.xPositions[2]) + (comBoat4.yPosition);
        comBoatPositions.add(point);
        comBoatList.add(comBoat4);

        comBoat2.yPosition = yPositionBoat2;
        comBoat2.xPositions[0] = xPositionBoat2;
        point = numberToLetter(comBoat2.xPositions[0]) + (comBoat2.yPosition);
        comBoatPositions.add(point);
        comBoat2.xPositions[1] = (xPositionBoat2 + 1);
        point = numberToLetter(comBoat2.xPositions[1]) + (comBoat2.yPosition);
        comBoatPositions.add(point);
        comBoat2.xPositions[2] = (xPositionBoat2 + 2);
        point = numberToLetter(comBoat2.xPositions[2]) + (comBoat2.yPosition);
        comBoatPositions.add(point);
        comBoat2.xPositions[3] = (xPositionBoat2 + 3);
        point = numberToLetter(comBoat2.xPositions[3]) + (comBoat2.yPosition);
        comBoatPositions.add(point);
        comBoatList.add(comBoat2);

        comBoat5.yPosition = yPositionBoat5;
        comBoat5.xPositions[0] = xPositionBoat5;
        point = numberToLetter(comBoat5.xPositions[0]) + (comBoat5.yPosition);
        comBoatPositions.add(point);
        comBoat5.xPositions[1] = (xPositionBoat5 + 1);
        point = numberToLetter(comBoat5.xPositions[1]) + (comBoat5.yPosition);
        comBoatPositions.add(point);
        comBoat5.xPositions[2] = (xPositionBoat5 + 2);
        point = numberToLetter(comBoat5.xPositions[2]) + (comBoat5.yPosition);
        comBoatPositions.add(point);
        comBoat5.xPositions[3] = (xPositionBoat5 + 3);
        point = numberToLetter(comBoat5.xPositions[3]) + (comBoat5.yPosition);
        comBoatPositions.add(point);
        comBoatList.add(comBoat5);

        comBoat3.yPosition = yPositionBoat3;
        comBoat3.xPositions[0] = xPositionBoat3;
        point = numberToLetter(comBoat3.xPositions[0]) + (comBoat3.yPosition);
        comBoatPositions.add(point);
        comBoat3.xPositions[1] = (xPositionBoat3 + 1);
        point = numberToLetter(comBoat3.xPositions[1]) + (comBoat3.yPosition);
        comBoatPositions.add(point);
        comBoat3.xPositions[2] = (xPositionBoat3 + 2);
        point = numberToLetter(comBoat3.xPositions[2]) + (comBoat3.yPosition);
        comBoatPositions.add(point);
        comBoat3.xPositions[3] = (xPositionBoat3 + 3);
        point = numberToLetter(comBoat3.xPositions[3]) + (comBoat3.yPosition);
        comBoatPositions.add(point);
        comBoat3.xPositions[4] = (xPositionBoat3 + 4);
        point = numberToLetter(comBoat3.xPositions[4]) + (comBoat3.yPosition);
        comBoatPositions.add(point);
        comBoatList.add(comBoat3);

        for (int x = 0; x < comBoatPositions.size(); x++) {
            System.out.println(comBoatPositions.get(x));
        }
    }

    public static void printBoat(boat ship, gridMaker frame) {
        // prints boats onto a grid of choice
        int x, y;
        x = ship.xPositions[0] * 50;
        y = ship.yPosition * 50;
        imageUploaderGrid(ship.fileName, frame, x, y, ship.width, ship.height);
    }

    public static void playerBoat(String turn, boat ship) {
        // takes a point on the grid and a boat and assigns positions to that boat
        int xPosition = letterToNumber(turn.charAt(0));
        int yPosition = Integer.parseInt(turn.substring(1));
        ship.yPosition = yPosition;
        ship.xPositions[0] = xPosition;
        playerBoatPositions.add(numberToLetter(xPosition) + (yPosition));
        int xPosition2 = (xPosition + 1);
        ship.xPositions[1] = xPosition2;
        playerBoatPositions.add(numberToLetter(xPosition2) + (yPosition));
        int xPosition3 = (xPosition + 2);
        ship.xPositions[2] = xPosition3;
        playerBoatPositions.add(numberToLetter(xPosition3) + (yPosition));
        if (ship.size >= 4) {
            int xPosition4 = (xPosition + 3);
            ship.xPositions[3] = xPosition4;
            playerBoatPositions.add(numberToLetter(xPosition4) + (yPosition));
        }
        if (ship.size == 5) {
            int xPosition5 = (xPosition + 4);
            ship.xPositions[4] = xPosition5;
            playerBoatPositions.add(numberToLetter(xPosition5) + (yPosition));
        }
        playerBoatList.add(ship);
    }
}